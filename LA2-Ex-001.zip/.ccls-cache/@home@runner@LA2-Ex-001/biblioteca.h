#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define LIN 6
#define COL LIN
#define LIMITE 99

void preencheMatrizAleatorios(int matriz[LIN][COL]);
void apresentaMatriz(int matriz[LIN][COL]);
void maiorColuna(int matriz[LIN][COL]);
int menorMatriz(int matriz[LIN][COL]);
int procuraValor(int matriz[LIN][COL], int numero);
int somaColuna(int matriz[LIN][COL], int coluna);
int somaLinha(int matriz[LIN][COL], int linha);
void diagonalPrincipal(int matriz[LIN][COL]);
void verificaOrdemCrescente(int matriz [LIN][COL]);
void verificaSequencia(int matriz[LIN][COL]);