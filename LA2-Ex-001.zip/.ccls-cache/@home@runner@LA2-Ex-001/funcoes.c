#include "biblioteca.h"

void preencheMatrizAleatorios(int matriz[LIN][COL]){
int i, j; 
  
srand(time(NULL));

  for(i = 0;i < LIN; i++){
    for(j = 0;j < COL; j++){
      matriz[i][j] = (rand() % LIMITE +1);
    }
  }
}

//-----------------------------------------------------------------------------------------------

void apresentaMatriz(int matriz[LIN][COL]){
  int i, j;

  printf("\n\nMatriz: \n\n");
  
  for(i = 0; i < LIN; i++){
    for(j = 0;j < COL; j++){
      printf("[%.2d] ", matriz[i][j]);
    }
    printf("\n");
  }
}

//-----------------------------------------------------------------------------------------------

void maiorColuna(int matriz[LIN][COL]){
  int i, j;
  int coluna;

  do{
    printf("\n\nDigite a Coluna que deseja encontrar o maior valor (1 a 6): "); 
    scanf("%d", &coluna);
      if(coluna < 1 || coluna > COL){
        printf("\nNumero Invalido!");
      }
  }while(coluna < 1 || coluna > COL);        
  
  int maiorValCol = matriz[0][coluna - 1];
  
  for(i = 0; i < LIN; i++){
      if(matriz[i][coluna - 1] > maiorValCol){
        maiorValCol = matriz[i][coluna - 1];
      }
  }
  
  printf("\n\nO maior valor da Coluna { %d } é: { %d }", coluna, maiorValCol);
}

//-----------------------------------------------------------------------------------------------

int menorMatriz(int matriz[LIN][COL]){
  int i, j;
  int menorValorMatriz = matriz[0][0];
  
    for(i = 0; i < LIN; i++){
      for(j = 0;j < COL; j++){
        if(matriz[i][j] < menorValorMatriz){
          menorValorMatriz = matriz[i][j];
        }
      }
    }
  return menorValorMatriz;
}

//-----------------------------------------------------------------------------------------------

int procuraValor(int matriz[LIN][COL], int numero){
  int i, j, aux = 0;
  
  for(i = 0; i < LIN; i++){
    for(j = 0;j < COL; j++){
      if(matriz[i][j] == numero){
        aux++;
      }
    }
  }
  return aux;
}

//-----------------------------------------------------------------------------------------------

int somaColuna(int matriz[LIN][COL], int coluna){
  int i, soma = 0;
  
    for(i = 0; i < LIN; i++){
          soma += matriz[i][coluna-1];
      }
  
  return soma;
}

//-----------------------------------------------------------------------------------------------

int somaLinha(int matriz[LIN][COL], int linha){
  int j, soma = 0;

    for(j = 0; j < COL; j++){
      soma += matriz[linha -1][j];
    }
  
  return soma;
}

//-----------------------------------------------------------------------------------------------

void diagonalPrincipal(int matriz[LIN][COL]){
  int i, j;
  
  for(i = 0; i < LIN; i++){
    for(j = 0;j < COL; j++){
      if(i == j) printf("[%.2d] ", matriz[i][j]);
    }
  }
}

//-----------------------------------------------------------------------------------------------

void verificaOrdemCrescente(int matriz [LIN][COL]){
  int i, j, condicaoCrescente, condicaoEncontrada = 0;

  for(i = 0; i < LIN; i++){
    condicaoCrescente = 1;
  
    for(j = 0; j < COL; j++){
      if(matriz[i][j] > matriz[i][j+1]){
        condicaoCrescente = 0;
        break;
      }
    }
    if(condicaoCrescente == 1){
      printf("\n\nA linha { %d } possui uma ordem crescente: \n", i+1);
      
      for(j = 0; j < COL; j++){
        printf("%d, ", matriz[i][j]);
      }
      condicaoEncontrada = 1;
    }
  }
    if(condicaoEncontrada == 0)
        printf("\n\nNenhuma linha possui ordem Crescente ");
}

//-----------------------------------------------------------------------------------------------

void verificaSequencia(int matriz[LIN][COL]){
  int i, j, k, n;
  int condicaoOrdemLinha = 0, condicaoOrdemColuna = 0, somaAteN = 0;

  do{
    printf("\n\nEntre com o Valor de N (2 a %d): ", LIN); scanf("%d", &n);
//se N for igual a 1 não seria uma sequencia
    
    if(n < 2 || n > 6){
      printf("\nValor Invalido!");
    }
  }while(n < 2 || n > 6);

  int sequencia[n];
  
  for(i = 0; i < n; i++){
    printf("\n\nEntre com o Valor de n%d: ", i+1); scanf("%d", &sequencia[i]);
  }
  
  for(i = 0; i < LIN; i++){
    somaAteN = 0;
    
    for(j = 0; j < COL; j++){
      if(matriz[i][j] == sequencia [somaAteN]){
        somaAteN ++;
        if(somaAteN == n){
          printf("\n\nA sequencia ");
            for(j = 0; j < n; j++){
              printf("{ %d } ", sequencia[j]);
            }
          printf("aparece na Linha { %d }", i+1);
          condicaoOrdemLinha = 1;
          break;
        }
      }else{
        somaAteN = 0;
      }
    }
  }
  
  for(i = 0; i < COL; i++){
    somaAteN = 0;
    
    for(j = 0; j < LIN; j++){
      if(matriz[j][i] == sequencia[somaAteN]){
        somaAteN ++;
          if(somaAteN == n){
            printf("\n\nA sequencia ");
              for(k = 0; k < n; k++){
                printf("{ %d } ", sequencia[j]);
              }
            printf("aparece na Coluna { %d }", i+1);
            condicaoOrdemColuna = 1;
            break;
          }
      }else{
        somaAteN = 0;
      }
    }
  }

  if((condicaoOrdemLinha == 0) && (condicaoOrdemColuna == 0)){
    printf("\n\nA sequencia ");
      for(j = 0; j < n; j++){
        printf("{ %d } ", sequencia[j]);
      }
    printf("Não está presente na matriz");
  }
}
