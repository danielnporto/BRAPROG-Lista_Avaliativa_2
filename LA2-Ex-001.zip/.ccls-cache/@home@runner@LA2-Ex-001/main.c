#include <stdio.h>
#include "biblioteca.h"

int main(void) {
int matriz[LIN][COL];
int opcao = 0, i, j, coluna, linha, procurado;
int escolhaInicio;

  printf("\n\n» Criando uma MATRIZ 6x6\n");

  do{
  printf("\n-> Se Deseja Digitar o Valor da Matriz Insira { 1 }\n-> Se Deseja Gerar Valores Aleatórios para Matriz Insira { 2 }\n\nResposta: "); 
  scanf("%d", &escolhaInicio);
    if(escolhaInicio < 1 || escolhaInicio > 2){
      printf("\nValor Invalido!\n");
    }
  }while(escolhaInicio < 1 || escolhaInicio > 2);
    
  if(escolhaInicio == 1){
    printf("\n----------\n");
    for(i = 0; i < LIN; i++){
      for(j = 0;j < COL; j++){
        printf("\nDigite o Valor da matriz de linha %d e coluna %d : ", i+1, j+1);
        scanf("%d", &matriz[i][j]);
      }
      printf("\n----------\n");
    }
  }else{
    preencheMatrizAleatorios(matriz);
  }  
  
  
  do {
        printf("\n\n--------------------------ESCOLHA--------------------------\n");
        printf("\nSelecione uma opcao:\n");
        printf("1. Exibir a matriz\n");
        printf("2. Encontrar maior valor de uma coluna\n");
        printf("3. Encontrar menor valor da matriz\n");
        printf("4. Verificar se um valor existe na matriz\n");
        printf("5. Realizar soma de coluna\n");
        printf("6. Realizar soma de linha\n");
        printf("7. Exibir elementos da diagonal principal\n");
        printf("8. Verificar linhas em ordem crescente\n");
        printf("9. Procurar sequência de valores na ordem fornecida\n");
        printf("10. Finalizar\n\nResposta: ");

        scanf("%d", &opcao); 

        printf("\n--------------------------/-/-/-/--------------------------");
    

        switch (opcao) {
            case 1:
                apresentaMatriz(matriz);
                break;
            case 2:
              maiorColuna(matriz);
                break;
            case 3:
              printf("\n\nO menor valor presente na matriz é: { %d }",  menorMatriz(matriz));
                break;
            case 4:
                printf("\n\nEntre com o valor que deseja encontrar na matriz: ");
              scanf("%d", &procurado);
                  if(procuraValor(matriz, procurado) >= 1){
                    printf("\nO Valor { %d } aparece na matriz! Em um total de { %d } vez(es)! ", procurado, procuraValor(matriz, procurado));
                  }else{
                    printf("\nO Número { %d } não está na matriz!", procurado);
                  }
                break;
            case 5:
                do{
                  printf("\n\nDigite a Coluna que deseja encontrar o maior valor (1 a 6): "); 
                  scanf("%d", &coluna);
                    if(coluna < 1 || coluna > COL){
                      printf("\nNumero Invalido!");
                    }
                }while(coluna < 1 || coluna > COL);
              
                printf("\nA soma dos valores da coluna { %d } é { %d }", coluna, somaColuna(matriz, coluna));
                break;
            case 6:
                do{
                  printf("\n\nDigite a Linha que deseja encontrar o maior valor (1 a 6): "); 
                  scanf("%d", &linha);
                    if(linha < 1 || linha > LIN){
                      printf("\nNumero Invalido!");
                    }
                }while(linha < 1 || linha > LIN);
                printf("\nA soma dos valores da Linha { %d } é { %d }", linha, somaLinha(matriz, linha));
                break;
            case 7:
                printf("\n\nElementos da Diagonal Principal: \n\n");
                diagonalPrincipal(matriz);
                break;
            case 8:
                verificaOrdemCrescente(matriz);
                break;
            case 9:
                verificaSequencia(matriz);
                break;
            case 10:
                printf("\nFinalizando...\n");
                break;
            default:
                printf("\nOpcao invalida!\n");
        }
    } while (opcao != 10);
  
  return 0;
}